#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

Actor::Actor(int imageID, double startX, double startY, StudentWorld* studWorld, int dir, int depth)
: GraphObject(imageID, startX, startY, dir, depth)
{
    m_isAlive = true;
    m_world = studWorld;
    m_ID = imageID;
}

StudentWorld* Actor::getWorld() const
{return m_world;}

int Actor::getID() const
{return m_ID;}

void Actor::setDeath()
{m_isAlive = false;}

void Actor::takeDamage(int amt)
{return;}

bool Actor::getLiveOrDeath() const
{return m_isAlive;}

void Actor::getPositionInThisDirection(Direction angle, int units, double &dx, double &dy) const
{
    const double PI = 4 * atan(1);
    dx = (getX() + units * cos(angle*1.0 / 360 * 2 * PI));
    dy = (getY() + units * sin(angle*1.0 / 360 * 2 * PI));
}

Actor::~Actor(){}

/*implementation for Socrates*/

Socrates::Socrates(int imageID, double startX, double startY, StudentWorld* studWorld, int dir, int depth)
: Actor(imageID, startX, startY, studWorld, dir, depth)
{
    setDirection(0);
    setHealth(100);
    m_nspray = 20;
    m_nflame = 5;
    m_posAngle = 180;
}

Socrates::~Socrates(){}

void Socrates::setHealth(int health)
{m_health = health;}

int Socrates::getHealth() const
{return m_health;}

void Socrates::setSpray(int amt)
{m_nspray += amt;}

int Socrates::getSpray() const
{return m_nspray;}

void Socrates::setFlame(int amt)
{m_nflame += amt;}

int Socrates::getFlame() const
{return m_nflame;}

Direction Socrates::getPosAngle() const
{return m_posAngle;}

void Socrates::setPosAngle(Direction angle)
{m_posAngle += angle;}

void Socrates::takeDamage(int amt)
{
    m_health += amt;
    if(m_health <= 0)
    {
        setDeath();
        getWorld()->playSound(SOUND_PLAYER_DIE);
    }
    else
        getWorld()->playSound(SOUND_PLAYER_HURT);
}

void Socrates::doSomething()
{
    if(!getLiveOrDeath()) // if player is dead
        return;
    
    int key;
    if(getWorld()->getKey(key))
    {
        const double PI = 4 * atan(1);
    // user hit a key during this tick!
        switch (key)
        {
            case KEY_PRESS_LEFT:
            {
                setPosAngle(5);
                Direction angle = getPosAngle();
                double newX = cos(angle*1.0/180 * PI)*VIEW_RADIUS + VIEW_RADIUS;
                double newY = sin(angle*1.0/180 * PI)*VIEW_RADIUS + VIEW_RADIUS;
                moveTo(newX, newY);
                setDirection(getPosAngle()+180);
                //... move Socrates counterclockwise ...;
                break;
            }
            case KEY_PRESS_RIGHT:
            {
                setPosAngle(-5);
                Direction angle = getPosAngle();
                double newX = cos(angle*1.0/180 * PI)*VIEW_RADIUS + VIEW_RADIUS;
                double newY = sin(angle*1.0/180 * PI)*VIEW_RADIUS + VIEW_RADIUS;
                moveTo(newX, newY);
                setDirection(getPosAngle()+180);
                //... move Socrates clockwise...;
                break;
            }
            case KEY_PRESS_SPACE:
            //... add spray in front of Socrates...;
            {
                if(m_nspray > 0)
                {
                    getWorld()->addSpray(this);
                    
                    setSpray(-1);
                getWorld()->playSound(SOUND_PLAYER_SPRAY);
                }
                break;
            }
            case KEY_PRESS_ENTER:
            //... add flame in front of Socrates...;
            {
                if(m_nflame > 0)
                {
                    getWorld()->addFlame(this);
                    
                    setFlame(-1);
                getWorld()->playSound(SOUND_PLAYER_FIRE);
                }
                break;
            }
        }
    }
    else if(getSpray() < 20)
        setSpray(1);
}



/*implementation for Dirt*/

Dirt::Dirt(int imageID, double startX, double startY, StudentWorld* studWorld, int dir, int depth)
: Actor(imageID, startX, startY, studWorld, dir, depth)
{}

void Dirt::doSomething(){}

void Dirt::takeDamage(int amt)
{setDeath();}

Dirt::~Dirt(){}


/*implementation for Food*/

Food::Food(int imageID, double startX, double startY, StudentWorld* studWorld, int dir, int depth)
: Actor(imageID, startX, startY, studWorld, dir, depth)
{}

Food::~Food(){}

void Food::doSomething(){};


/*implementation for Projectile*/

Projectile::Projectile(int imageID, double startX, double startY, StudentWorld* studWorld, int dir, int depth)
: Actor(imageID, startX, startY, studWorld, dir, depth), m_maxDist(0), m_distMoved(0)
{}

void Projectile::setMaxDist(int MaxDist)
{m_maxDist = MaxDist;}

void Projectile::setDistMoved(int distMoved)
{
    m_distMoved += distMoved;
}

double Projectile::getDistMoved() const
{return m_distMoved;}

double Projectile::getMaxDist() const
{return m_maxDist;}

void Projectile::takeDamage(int amt)
{return;}

Projectile::~Projectile(){}

/*implementation for Flame*/

Flame::Flame(int imageID, double startX, double startY, StudentWorld* studWorld, int dir, int depth)
: Projectile(imageID, startX, startY, studWorld, dir, depth)
{
    setMaxDist(32);
}

Flame::~Flame(){}

void Flame::doSomething()
{
    if(!getLiveOrDeath())
        return;
    Actor* a = getWorld()->getDamagableObject(this);
    if(a != nullptr)
    {
        a->takeDamage(2);
        setDeath();
    }
    else
    {
        if(getDistMoved() < getMaxDist())
            //else move forward 2*sprite_radius in current dir
        {
            moveForward(2*SPRITE_RADIUS);
            setDistMoved(2*SPRITE_RADIUS);
        }
        else
            this->setDeath();
    }
}

/*implementation for Spray*/

Spray::Spray(int imageID, double startX, double startY, StudentWorld* studWorld, int dir, int depth)
: Projectile(imageID, startX, startY, studWorld, dir, depth)
{
    setMaxDist(112);
}

Spray::~Spray(){}

void Spray::doSomething()
{
    if(!getLiveOrDeath())
        return;
    Actor* a = getWorld()->getDamagableObject(this);
    if(a != nullptr)
    {
        a->takeDamage(2);
        setDeath();
    }
    else
    {
        if(getDistMoved() < getMaxDist())
            //else move forward 2*sprite_radius in current dir
        {
            moveForward(2*SPRITE_RADIUS);
            setDistMoved(2*SPRITE_RADIUS);
        }
        else
            this->setDeath();
    }
    
}

/*implementation for Goodie*/

Goodie::Goodie(int imageID, double startX, double startY, StudentWorld* studWorld, int dir, int depth)
: Actor(imageID, startX, startY, studWorld, dir, depth)
{
    lifetime = max(rand() % (300 - 10 * getWorld()->getLevel()), 50);
}

Goodie::~Goodie(){}

void Goodie::decLifetime()
{lifetime--;}

int Goodie::getLifetime() const
{return lifetime;}

void Goodie::takeDamage(int amt)
{setDeath();}

/*implementation for RHG*/

RestoreHpGoodie::RestoreHpGoodie(int imageID, double startX, double startY, StudentWorld* studWorld, int dir, int depth)
: Goodie(imageID, startX, startY, studWorld, dir, depth)
{}

RestoreHpGoodie::~RestoreHpGoodie(){}

void RestoreHpGoodie::doSomething()
{
    if(!getLiveOrDeath())
        return;
    if(getWorld()->isOverlap(this, getWorld()->getPlayer(), 2.0*SPRITE_RADIUS))
    {
        getWorld()->increaseScore(250);
        setDeath();
        getWorld()->playSound(SOUND_GOT_GOODIE);
        getWorld()->getPlayer()->setHealth(100);
        return;
    }
    decLifetime();
    if(getLifetime() == 0)
        setDeath();
}

/*implementation for FTG*/

FlameGoodie::FlameGoodie(int imageID, double startX, double startY, StudentWorld* studWorld, int dir, int depth)
: Goodie(imageID, startX, startY, studWorld, dir, depth)
{}

FlameGoodie::~FlameGoodie(){}

void FlameGoodie::doSomething()
{
    if(!getLiveOrDeath())
        return;
    if(getWorld()->isOverlap(this, getWorld()->getPlayer(),2.0 *SPRITE_RADIUS))
    {
        getWorld()->increaseScore(300);
        setDeath();
        getWorld()->playSound(SOUND_GOT_GOODIE);
        getWorld()->getPlayer()->setFlame(5);
        return;
    }
    decLifetime();
    if(getLifetime() == 0)
        setDeath();
}

/*implementation for ELG*/

ExtraLifeGoodie::ExtraLifeGoodie(int imageID, double startX, double startY, StudentWorld* studWorld, int dir, int depth)
: Goodie(imageID, startX, startY, studWorld, dir, depth)
{}

ExtraLifeGoodie::~ExtraLifeGoodie(){}

void ExtraLifeGoodie::doSomething()
{
    if(!getLiveOrDeath())
        return;
    if(getWorld()->isOverlap(this, getWorld()->getPlayer(),2.0 *SPRITE_RADIUS))
    {
        getWorld()->increaseScore(500);
        setDeath();
        getWorld()->playSound(SOUND_GOT_GOODIE);
        getWorld()->incLives();
        return;
    }
    decLifetime();
    if(getLifetime() == 0)
        setDeath();
}

/*implementation for Fungus*/

Fungus::Fungus(int imageID, double startX, double startY, StudentWorld* studWorld, int dir, int depth)
: Goodie(imageID, startX, startY, studWorld, dir, depth)
{}

Fungus::~Fungus(){}

void Fungus::doSomething()
{
    if(!getLiveOrDeath())
        return;
    if(getWorld()->isOverlap(this, getWorld()->getPlayer(),2.0 *SPRITE_RADIUS))
    {
        getWorld()->increaseScore(-50);
        setDeath();
        
        getWorld()->getPlayer()->takeDamage(-20);
        if(getWorld()->getPlayer()->getHealth() <= 0)
            getWorld()->getPlayer()->setDeath();
        return;
    }
    decLifetime();
    if(getLifetime() == 0)
        setDeath();
}

/*implementation for Pit*/

Pit::Pit(int imageID, double startX, double startY, StudentWorld* studWorld, int dir, int depth)
: Actor(imageID, startX, startY, studWorld, dir, depth), m_nRegSal(5), m_nAggSal(3), m_nEcoli(2)
{}

Pit::~Pit(){}

void Pit::doSomething()
{
    if(m_nRegSal == 0 && m_nEcoli == 0 && m_nAggSal == 0)
        setDeath();
    else
    {
        if(randInt(1, 50) == 50)
        {
            switch (randInt(1, 3)){
                case 1:
                    if(m_nRegSal != 0)
                    {
                        getWorld()->addBacteria("RegSal", getX(), getY());
                        m_nRegSal--;
                        break;
                    }
                case 2:
                    if(m_nAggSal != 0)
                    {
                        getWorld()->addBacteria("AggSal",  getX(), getY());
                        m_nAggSal--;
                        break;
                    }
                    if(m_nRegSal != 0)
                    {
                        getWorld()->addBacteria("RegSal",  getX(), getY());
                        m_nRegSal--;
                        break;
                    }
                case 3:
                    if(m_nEcoli != 0)
                    {
                        getWorld()->addBacteria("Ecoli",  getX(), getY());
                        m_nEcoli--;
                        break;
                    }
                    if(m_nRegSal != 0)
                    {
                        getWorld()->addBacteria("RegSal",  getX(), getY());
                        m_nRegSal--;
                        break;
                    }
                    if(m_nAggSal != 0)
                    {
                        getWorld()->addBacteria("AggSal",  getX(), getY());
                        m_nAggSal--;
                        break;
                    }
            }
            getWorld()->playSound(SOUND_BACTERIUM_BORN);
        }
    }
}

/*implementation for Bacteria*/

Bacteria::Bacteria(int imageID, double startX, double startY, StudentWorld* studWorld, int dir, int depth)
: Actor(imageID, startX, startY, studWorld, dir, depth), m_movePlanDist(0),m_health(0),m_nFoodEaten(0)
{}

Bacteria::~Bacteria(){}

int Bacteria::getHealth() const
{return m_health;}

void Bacteria::setHealth(int health)
{m_health = health;}

int Bacteria::getMovePlanDist() const
{return m_movePlanDist;}

void Bacteria::takeDamage(int amt)
{}

void Bacteria::setMovePlanDist(int num)
{m_movePlanDist += num;}

int Bacteria::getFoodEaten() const
{return m_nFoodEaten;}

void Bacteria::setFoodEaten(int amt)
{m_nFoodEaten = amt;}

void Bacteria::nextMove()
{
    if(getMovePlanDist() > 0) //step 5
    {
        setMovePlanDist(-1);
        
        bool isOverlap = false;
        for(int i = 0; i <= 3; i++)
        {
            double newX, newY;
            getPositionInThisDirection(getDirection(), i, newX, newY);
            if(getWorld()->isBlockingDirt(newX, newY))
            {
                isOverlap = true;
                break;
            }
        }
        double newX, newY;
        getPositionInThisDirection(getDirection(), 3, newX, newY);
        double distToCtr = sqrt(pow(newX - VIEW_WIDTH/2, 2) + pow(newY - VIEW_HEIGHT/2, 2));
        if(distToCtr <= VIEW_RADIUS && !isOverlap)
            moveTo(newX, newY);
        else
        {
            int randDir = randInt(0, 359);
            setDirection(randDir);
            setMovePlanDist(10-getMovePlanDist());
        }
        return;
    }
    else //step 6
    {
        Actor* a = getWorld()->getFoodAround(this,VIEW_RADIUS);
        if(a != nullptr)
        {
            double distFromFood = sqrt(pow(this->getX() - a->getX(), 2) + pow(getY() - a->getY(), 2));
            bool isOverlap = false;
            for(int i = 0; i <= int(distFromFood); i++)
            {
                double newX, newY;
                getPositionInThisDirection(getDirection(), i, newX, newY);
                if(getWorld()->isBlockingDirt(newX, newY))
                {
                    isOverlap = true;
                    break;
                }
            }
            if(isOverlap)
            {
                int randDir = randInt(0, 359);
                setDirection(randDir);
                setMovePlanDist(10-getMovePlanDist());
            }
            else
                moveTo(a->getX(), a->getY());
        }
        else
        {
            int randDir = randInt(0, 359);
            setDirection(randDir);
            setMovePlanDist(10-getMovePlanDist());
            return;
        }
    }
}
/*implementation for RegSal*/

RegSal::RegSal(int imageID, double startX, double startY, StudentWorld* studWorld, int dir, int depth)
: Bacteria(imageID, startX, startY, studWorld, dir, depth)
{
    setHealth(4);
}

RegSal::~RegSal(){}

void RegSal::takeDamage(int amt)
{
   setHealth(getHealth()+amt);
    if(getHealth() <= 0)
    {
        setDeath();
        getWorld()->playSound(SOUND_SALMONELLA_DIE);
        getWorld()->increaseScore(100);
        if(randInt(0, 1) == 0)
            getWorld()->addFood(this);
    }
    else
        getWorld()->playSound(SOUND_SALMONELLA_HURT);
        
}

void RegSal::doSomething()
{
    if(!getLiveOrDeath()) //step 1
        return;
    if(getWorld()->isOverlap(this, getWorld()->getPlayer(),2.0 *SPRITE_RADIUS)) // step 2
    {
        getWorld()->getPlayer()->takeDamage(-1);
        nextMove(); //step 5/6
    }
    else
    {
        if(getFoodEaten() == 3) // step 3
        {
            int newX = getX(), newY = getY();
            if(getX()<VIEW_WIDTH/2)
                newX = getX()+SPRITE_RADIUS;
            if(getX()>VIEW_WIDTH/2)
                newX = getX()-SPRITE_RADIUS;
            if(getY()<VIEW_HEIGHT/2)
                newY = getY()+SPRITE_RADIUS;
            if(getY()>VIEW_HEIGHT/2)
                newY = getY()-SPRITE_RADIUS;
            getWorld()->addBacteria("RegSal", newX, newY);
            setFoodEaten(0);
            nextMove(); //skip to step 5
        }
        Actor* a = getWorld()->getFoodAround(this, 2*SPRITE_RADIUS);
        if(a != nullptr)
        {
            setFoodEaten(getFoodEaten()+1);
            a->setDeath();
        }
    }
}


/*implementation for AggSal*/

AggSal::AggSal(int imageID, double startX, double startY, StudentWorld* studWorld, int dir, int depth)
: Bacteria(imageID, startX, startY, studWorld, dir, depth)
{
    setHealth(10);
}

AggSal::~AggSal(){}

void AggSal::takeDamage(int amt)
{
   setHealth(getHealth()+amt);
    if(getHealth() <= 0)
    {
        setDeath();
        getWorld()->playSound(SOUND_SALMONELLA_DIE);
        getWorld()->increaseScore(100);
        if(randInt(0, 1) == 0)
            getWorld()->addFood(this);
    }
    else
        getWorld()->playSound(SOUND_SALMONELLA_HURT);
        
}

void AggSal::doSomething()
{
    if(!getLiveOrDeath())
        return;
    if(getWorld()->isOverlap(this, getWorld()->getPlayer(),72))
    {
        /// if not get blocked by dirt:
        moveTo(getWorld()->getPlayer()->getX(), getWorld()->getPlayer()->getY());
        
        /// else :
        
        if(getWorld()->isOverlap(this, getWorld()->getPlayer(), 2.0*SPRITE_RADIUS))
        {
            getWorld()->getPlayer()->takeDamage(-2);
            
            if(getWorld()->isOverlap(this, getWorld()->getPlayer(),72))
                return;
        }
        
    }
}


/*implementation for Ecoli*/

Ecoli::Ecoli(int imageID, double startX, double startY, StudentWorld* studWorld, int dir, int depth)
: Bacteria(imageID, startX, startY, studWorld, dir, depth)
{
    setHealth(5);
}

Ecoli::~Ecoli(){}

void Ecoli::takeDamage(int amt)
{
   setHealth(getHealth()+amt);
    if(getHealth() <= 0)
    {
        setDeath();
        getWorld()->playSound(SOUND_ECOLI_DIE);
        getWorld()->increaseScore(100);
        if(randInt(0, 1) == 0)
            getWorld()->addFood(this);
    }
    else
        getWorld()->playSound(SOUND_ECOLI_HURT);
        
}

void Ecoli::doSomething()
{
    if(!getLiveOrDeath())
        return;
    if(getWorld()->isOverlap(this, getWorld()->getPlayer(), 2.0*SPRITE_RADIUS))
    {
        getWorld()->getPlayer()->takeDamage(-4);
        if(getWorld()->getPlayer()->getHealth() <= 0)
        getWorld()->getPlayer()->setDeath();
        
        if(getWorld()->isOverlap(this, getWorld()->getPlayer(), 256))
        {
            double xApart = getWorld()->getPlayer()->getX() - this->getX();
            double yApart = getWorld()->getPlayer()->getY() - this->getY();
            Direction d = atan(yApart/xApart);
            for(int i = 0; i < 10; i++)
            {
                bool isBlocked = false;
                /// if not blocked by dirt
                if(!isBlocked)
                {
                    moveAngle(d);
                    return;
                }
                else{
                    if(d + 10 >= 360)
                        d = d + 10 - 360;
                    d += 10;
                }
            }
        }
    }
    //if eat a total if 3 food (step 3/4)
}
